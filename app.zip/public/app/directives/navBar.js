Books.directive('navbar', function() {
	return{
		restrict : "E",
		templateUrl : "public/template/navbar.html"
	}
});