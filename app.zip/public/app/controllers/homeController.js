"use strict";

Books.controller('homeController',
	['$scope','$http','$location',
	function($scope,$http,$location){



}]);