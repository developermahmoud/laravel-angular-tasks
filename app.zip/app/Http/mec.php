<?php 
/**
 * Mec Function
 */
function getNum()
{
	return "okay ";
}